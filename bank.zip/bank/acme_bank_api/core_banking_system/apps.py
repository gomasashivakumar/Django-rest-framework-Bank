from django.apps import AppConfig


class CoreBankingSystemConfig(AppConfig):
    name = 'acme_bank_api.core_banking_system'
    verbose_name = 'Core Banking'
